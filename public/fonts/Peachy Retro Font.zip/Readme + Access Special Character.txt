-----------------------------------------------------------------

This font is Commercial Use, Enjoy!

Visit my store for more great fonts :
https://dharmasstudio.com

If you need extended license or more :
dharmasahestya@gmail.com

Big Thanks

-----------------------------------------------------------------

- HOW TO INSTALL FONT

	Open Font, Click Instal
	( Just choose one OTF or TTF )

- HOW TO ACCESS ALTERNATE AND LIGATURE IN ADOBE ILLUSTRATOR/PHOTOSHOP

	Open glyphs panel :

	 - ADOBE PHOTOSHOP
	    go to Window - Glyphs

 	 - ADOBE ILLUSTRATOR
	    go to Window - Type - Glyphs

- ACCESS ALTERNATE AND LIGATURE IN CANVA & PROCREATE

	 - CANVA
	   You can show it up by copy-paste the character map from your device, see detail here: www.youtube.com/watch?v=sjmQHQ5jhl8

	 - PROCREATE
	   Install a program first named "Unicode Character Viewer", then copy-paste it. Detail here : https://www.youtube.com/watch?v=0eRvkzO9tIQ


-----------------------------------------------------------------

More Information please contact me :

dharmasahestya@gmail.com